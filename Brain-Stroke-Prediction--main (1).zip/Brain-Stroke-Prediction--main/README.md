# Brain-Stroke-Prediction-
This project contains brain stroke prediction model using CNN and LSTM hybrid model which has more accuracy.
-> Chatbot_work has python file for the model along with te preprocessing steps invilved in it and all the metrices to measure the performance of matrices
-> In app.py it contains the implementation  of the model done in Spyder as Flask App . Run App.py in Spyder to  See the Output.
Remaining folders and Files are related to the front- end part of the Flask App built for Running the Application .
